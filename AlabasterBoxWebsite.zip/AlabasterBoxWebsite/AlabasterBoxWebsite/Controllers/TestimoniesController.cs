﻿using Microsoft.AspNetCore.Mvc;

namespace AlabasterBoxWebsite.Controllers
{
    public class TestimoniesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
